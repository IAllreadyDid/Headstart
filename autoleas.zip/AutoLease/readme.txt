Title of Program and Version    :AutoLease Advisor v.1.1.3

Suggested Category (optional)   :Personal Finance

Windows Version (3.1, NT or 95) :3.1, 95, NT

Uploader Email Address          :MediaQ@jps.net

Distributable on CDROM (yes/no) :yes

Description - 10 lines or less.  Start on the next blank line.

AutoLease Advisor is an easy-to-use guide to help anyone intending to lease a vehicle
make sense of this complex process. With comprehensive help
and guideance, this program could save the user much money and
anguish. Features include extensive lease terminology explaination,
on-line help at every step, leases explained in a simple FAQ
format, lease suitability gauge, comparison to conventional loan
financing, and much more.

Suitable for Windows 3.x, 95 and NT.

Installation: The program comes as a self-installing executable

Program Status: This program is shareware and is freely distributable. It is fully functional shareware. The purchasable full version offers the user more features. It's code and contents are all copyright of the author.

Contact the author in the event of a question at: MediaQ@jps.net
---------------------------------------------------------------