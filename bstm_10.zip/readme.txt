Thank you for trying out BrainStormer. BrainStormer is 
software designed to help you generate lots of creative 
ideas and then determine which idea is most suitable. 
BrainStormer is ideal for:

o Creative problem solving
o Devising new product ideas
o Creating new corporate strategies
o Establishing personal or corporate goals
o and much more!

BrainStormer is certain to bring out the creative genius 
in everyone!

To install BrainStormer, simply unzip it and then double-
click SETUP.EXE. 

BrainStormer is shareware. You are free to try it for 30 
days, after which time you must either register it or 
remove it from your computer. The single user 
registration fee is only US$35. You may distribute the 
unzipped version of BrainStormer or the self-extracting 
version BrainStormer (available at 
ftp.jpb.com/pub/creative/bstm_10.exe) freely. 

If you have questions or comments, please contact JPB 
Creative Co, Ltd at 12/23 Soi Prommitr, Sukhumvit 39 
Road, Bangkok 10110 Thailand; tel:+66(2)258 8451, 259 
7058; Fax: +66(2)261 6679; E-mail: info@jpb.com

BrainStormer is a JPB Creative product - 
http://www.jpb.com
