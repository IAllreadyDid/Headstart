Program:	Invoicer
Version:	3.18
Author:		Peter Hughes

Install:	Just run Invoicer.exe. You will require VBRun300.dll
		Either download it from Microsoft or from Simtel if you 		need it. Email runtimes@Simtel.net for a full listing. 
Purpose:	To create invoices
Distributed as:	Shareware. Freely distributable. 
		(without registration key)

Contact:	peter@madcap-software.co.uk

	Peter Hughes. 
	84b Warrior Square
	St Leonards on Sea
	East Sussex, TN37 6BP
	United Kingdom

Note:	There are no functions disabled, there is a 20 second delay
	to encourage registration.