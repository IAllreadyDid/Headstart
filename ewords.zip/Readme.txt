eWords for Windows

Challenging word game.  Play against the computer or up to 3 opponents across a network.  Great vocabulary-builder.

Install:  ewsetup.exe is a self-extracting file.

Status:  Shareware, freely distributable

Contact:  
ediSys Corp.
8333 Douglas Avenue, Suite 550
Dallas, TX  75225
eMail: sales@edisys.com
Phone:  (214)368-7470
Fax:  (214)368-7696