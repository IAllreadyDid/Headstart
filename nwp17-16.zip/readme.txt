NoteWorthy Player 1.70, NWC and MIDI File Player for Windows

A freeware player for NoteWorthy Composer song files. The player will load and play files created by registered users of the NoteWorthy Composer program. It will also load, notate, and play standard MIDI files, so it can be used a standard MIDI player. The MIDI Mapper is used for all play back operations.

** Minimum Hardware Requirements:
- 80386 PC
- 4 Meg of available RAM (16-bit edition)
  16 Meg of available RAM (32-bit edition)
- Sound card or MIDI port
- VGA or better monitor

** Operating System Requirements:
16-bit edition: Windows 3.1
32-bit edition: Windows 95/Windows 98/Windows NT 4.0/Windows 2000

** Keywords:
NtWorthy;NoteWorthy;Player;Composer;NWC;Notation;MIDI;Music;
Score;Freeware;Soundcard;SoundBlaster;Multimedia;Windows


** Getting Support/Providing Feedback:
You can find us on the web by starting at the following URL:

	http://NoteworthySoftware.com

You can reach NoteWorthy Software by e-mail at:

	support@noteworthysoftware.com

Alternately, if you do not have access to us via on-line methods, you may write to:

	NoteWorthy Software, Inc.
	PO Box 995
	Fuquay-Varina, NC 27526-0995
	USA


Copyright � 2000 by NoteWorthy Software, Inc.
All Rights Reserved
