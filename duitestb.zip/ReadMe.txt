DUITESTB.EXE VERSION 1.1
Needs VBRUN100.DLL to operate with Windows '95 or higher
Copyright. All rights reserved.
Shareware. Distribute Freely.

YOU ARE RESPONSIBLE FOR THE USE / MISUSE OF THIS PROGRAM
	 This program uses the 'Widmark' Formula to calculate BAC levels.
	DUITestB.EXE is for testing a person's reaction and coordination
	times while consuming alcohol. The 'Widmark' formula and the BAC
	levels the formula produces can be used in a criminal trial with the
	interpretation and testimony of a Forensic Pathologist in most
	states, as I understand it.
	 I began this project thinking I could finish it in an evening, just
	curious if I was too impaired to run to the store and get some
	(politically unpopular) cigarettes, and	doubtful that my reaction
	times at a BAC level of .100 could be any where close to an elderly
	individual's whose maximum is 45 MPH at high noon on a chrystal clear
	day on a flat straight interstate.
	 Not so. I began to wonder why people are jailed for being impaired
	by alcohol. My Grandmother's ability to drive has been impaired by
	age. I've driven impaired by lack of sleep, exhaustion, sickness,
	anxiety, medication, distraction, etc... All without being arrested
	and jailed. Why alcohol? Why are people in my home town being
	arrested and jailed for Public Intoxication for drinking on their
	own front porch (no joke). 
	 Next Generation Prohibition! More intrusion into your private life!
	 What is impaired driving? Use this program to check your response
	times to the test and see how you do. Your reaction time will be
	affected by many factors including (but not limited to), how much
	sleep you've had, if you've eaten, what you've eaten, your medical
	condtion, (age, depression, diabetes, anxiety, arthritis, etc...),
	your use of prescription medication, over the counter drugs, and
	illegal drugs such as marijuana. See "help.txt" for information on
	how to operate this program.	 
	 Please don't use this program to drink and drive. There are many
	variable factors as to your BAC level and your ability to operate
	machinery or a motor vehicle. Remember, the only test that
	matters is the one the police, or the company administers.
	
	 The alcohol content of the beer in this program cannot be guaranteed
	because beer makers are prohibited by law to advertise the alcohol
	content of their product. However the User of this program can add to
	and/or, delete and change the names and alcohol content of the beer
	contained in this program. If you're not sure of the alcohol content
	of the beer you're drinking, ask at the liquor store, they should
	know. If not, call the company. Or maybe just ask a couple of
	friends.
	
	 This program is provided as Shareware by John Fracaro. If you like
	it and intend to keep using it, the cost is $5.00. Registered users
	will be entitled to a free upgrade to this program when it becomes
	available. (Many more features and much more to do.) Future versions
	are contingent upon user feedback and paying the Shareware
	Registration Fee. (Programming requires a huge investment of time,
	and sometimes money.) Don't forget to include your home address,
	and email address with payment, for a free upgrade.  

Send to:
John Fracaro
7472 E. 1100 N.
Kendallville IN 46755

Send questions, comments, suggestions to:
wildone@noble.cioe.com (email checked more often here)
JFracaro@aol.com
All email will be responded to.
