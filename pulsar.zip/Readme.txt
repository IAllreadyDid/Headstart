Visual Planets 2.0 and
The Windows Dictionary of Astronomy (2nd Edition) for Windows
Copyright �1997-1998 Pulsar Publishing
All Rights Reserved

Pulsar Publishing
56 Kimbolton Close
Lee,
London
SE12 OJJ
UNITED KINGDOM
Tel: 0181-488-1701
Email: jmwebb@dircon.co.uk
WWW: http://www.astrosoftware.com

This program is distributed through:
DITR Marketing, Inc.
11772 Sorrento Valley Road, Suite 120
San Diego, CA 92121
U.S.A.


SUMMARY

The Windows Dictionary of Astronomy is a comprehensive
computerised astronomical dictionary. This user-friendly
software package for Windows 3.1, 95 or NT incorporates
some 2000 terms together with associated terms incorporating
direct hypertext links to related educational articles,
providing a deeper understanding of astronomy. The program
is designed to assist all those in the pursuit of astronomical
knowledge and should prove of value to those studying
astronomy at school and university and to amateur and armchair
astronomers and would also be a useful general reference for
professionals.

We hope you enjoy the program.




SYSTEM REQUIREMENTS

IBM or compatible PC
Running Windows 3.1, 95 or NT
386 or higher processor,
At least 6mb RAM
256 Colour Monitor
Mouse


INSTALLATION

1. The WDADEMO.EXE file is a self extracting\installer.
   put the file into a folder (C:\temp is recommended).
2. Start WDADEMO.EXE and follow on screen instructions.



NEW ORDER DETAILS FROM 03/09/97
-----------------
The order details contained within the program have now changed.
Please use the following avanues to purchase your copy of WDA.

REGISTERING IN THE UNITED KINGDOM

If registering from the UK, please use "Order Form UK" in the program group. 
Registration is UK �14.95. 



REGISTERING IN THE USA

Registration is U.S. $23.95.  To order diskettes with registration, add $5.00.


To purchase this product, contact DITR Marketing, Inc.

There are three ways to order:
	Order on-line:
	with a credit card at http://www.ditr.com/software/pulsar/order.html

	Order by phone:  
	1 (619) 259-4700
	Toll-free order hotline within the U.S. 1 (888) FOR-DITR

	Order by mail: 
	Send checks, money orders, or cash in $U.S. funds to:
	DITR Marketing, Inc.
	11772 Sorrento Valley Road, Suite 120
	San Diego, CA 92121
	U.S.A.


         
DISTRIBUTION

You may freely distribute the demo version of Windows Dictionary
of Astronomy as long as no alterations are made to the files.



DISCLAIMER

THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY WARRANTIES EXPRESSED
OR IMPLIED. THE USER IS RESPONIBLE FOR THE USE OF THIS PRODUCT AND ANY
DAMAGE RESULTING FROM IT.

