CW3 by William A. Thompson
Beta version 0.91

This program is intended to help the user practice the International 
Morse Code (sometimes called cw) so that they may be able to get 
an Amateur Radio License.  The program can send cw at 5 to 35 words 
per minute.  It can send text from a prepared file, random letters, 
or random words.  It will allow the user to print the text that has 
been sent or to save the sent text to a file.  That file can then be 
sent again later, if desired.  
---------------------------------------------------------------------
Installation
1. Create a new directory
2. Copy the zip file into the new directory
3. Unzip the contents of this file to the new directory.
4. From the file manager or Windows Explorer, double click on cw3.exe
to start the program.

You may also want to create a shortcut for CW3.  In Windows 95, right
click with the mouse on cw3.exe.  A menu will come up, one of the choices 
is to "create a shortcut".  Scroll down and select "create a shortcut".
If you right click on the start menu and click on "open", then double 
click on programs, it opens the programs folder.  Drag the shortcut to CW3
into the folder and release it.  Now click on start and the shortcut 
will show up in programs.
----------------------------------------------------------------------
This program is freeware.  This means that you may make as many 
copies of the program as you like and give it to anyone you wish 
to give it to.  You may NOT sell the program, but you may charge 
a nominal copying charge of less than $6.00 (US Dollars) for 
providing a copies to others.  You may also include this program 
on a CD-ROM or DVD-ROM as part of a collection of shareware/freeware 
programs.  You may not change this program or its help file in any way.

Any comments about this program should be directed to:

billth8@juno.com
Changes in release 0.91:
1.  Added support for soundcards.
2.  @xy special characters no longer have a space after them.
3.  Fixed occasional crash when sending with internal speaker.

Know problems in this release:
1.  rapidly clicking on the "start" and "stop" menu items will 
start more than one CW generator process, resulting in garbled
code being sent.

2.  Unpredictable behavior if two copies of CW3 are run at the same 
time.
