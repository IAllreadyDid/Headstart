1. SHORTKUTTS is a reference tool for Word Processing and Spreadsheet software. It helps the user of MS Word, MS Excel, WordPerfect, and Lotus 123 find all shortcut keys used by one of the above products (i.e. COPY = CTRL+C) as the user works on the above software. It also has printing functionality to print all shortcut keys by category. This eliminates the necessity to research the product's reference manual for the answer. This is a time saving product that could be used in the home, office, or educational markets.
2. Download SHORTKUTTS.zip.
   Unzip file and execute the Codex3.exe.
   When the SHORTKUTTS program is started a panel is displayed and
   remains on the monitor in the upper left hand side until the exit
   icon is clicked with the left button mouse. This gives you access to the 
   SHORTKUTTS system while working in other programs at the same time. 
   Once the system is deactivated it can be restarted by selecting the
   Codex3.exe. Each panel operates and looks similar so you don't get
   bothered by learning new commands for each panel. Depending on what 
   product is selected, each panel looks the same. A subject is selected
   out of the key subjects box which produces a list of items under the 
   subject selected. When an item is selected, the short cut key sequence is
   shown in the short cut key box. The print function has been disabled 
   in this demo version.   	 
3. Shareware, Demo
4. Freely Distributable
5. Problems, Questions, email us at voorteksoftware@erols.com
Attn: Dave Adamson

