README.TXT for QwikLook ver 1.00
------------------------------------------------------------

Welcome to QwikLook v1.00

 Purpose:
-----------
With this Program you will be able to keep addresses and phone numbers for your family and friends. 
   - Allows you to create and maintain personal information
   - Easy search 
   - Send Emails
   - Open Browser to specific WEB page
   - Keep notes


 Installation:
---------------
Simply click on the QwikLook.exe setup program and follow    instructions on what to do next. The program will create a directory in your Program File called QwikLook. You also will have an icon created on your desktop.


 Problems after Installation: 
-------------------------------
You may need to download vbrun300.dll. It can be downloaded at the site you got this program, or many other sites have it. It would be well worth downloading for use with this program.


 Distribution:
-----------------
This is a WYSIWYG program and is freeware. You may make copies and use it on as many computers as you like. You may give this program to whom ever you wish.
  

 Contact Author:
-----------------
You can contact me via email: ejj0630@excite.com or when using the program click on the Help menu - Send Comments.


 Known Bugs
-------------
Once you have added a name to you address book you will not be able to delete it from the listbox using the delete command. You need to follow these instructions to remove name from the list. If its only a couple of names I'm not sure its necessary to delete it, but its up to you.

              **** If in doubt do not save changes ****

	1. Open Notepad
	2. Open file, when dialog box comes up click on "All files" 
	3. Open directory where list.dat file is located.                         (c:\program files\qwiklook)
	4. Open "list.dat"
	5. Remove the name by placing the cursor in front of the name             (include the Parentheses).
	6. Press delete key on your keyboard until name below moves               into the position of the deleted name. 
	7. Save by opening file then click on save.
	8. Close your program

        
 
 

