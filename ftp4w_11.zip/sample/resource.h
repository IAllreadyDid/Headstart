/* ----------------------------------------- */
/*          r e s o u r c e . h              */
/* ----------------------------------------- */

#define CW_CONNECT                      1
#define CW_RECV                         2
#define CW_SEND                         3
#define CW_ABORT                        4
#define CW_DISCONNECT                   5
#define CW_QUIT                         6

#define CW_LONGDIR                      10
#define CW_SHORTDIR                     11

#define CW_SETVERB                      20
#define CW_SYNC                         21
#define CW_GAUGE                        22
#define CW_BINARY                       23

#define CW_MENU                         101
#define CW                              102
