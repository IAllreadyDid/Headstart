Home Labeler 3 - Special Edition
Copyright 1994-1997, Projexis Inc.
All rights reserved.



PRODUCT DESCRIPTION

Home Labeler easily combines text and graphics. Create your own graphics with: your scanner, your favorite graphical editor or Windows OLE (Object Linking and Embedding).

Features:
� Labels can be any size...many standard sizes
  come preset 
� Place text anywhere, in any font and color 
� Use preloaded graphics or create your own 
� Add scanned images (scanner and software req'd.)
� Arrays your label for multiple copies on the sheet
� On-line help and tutorials make you an expert in
   minutes
� Access your graphical editor from inside 
   Home Labeler.
� Create sloped text 
� All printer and label settings can be saved
� Define and name your own text styles 
� Customize the text list 
� Preview graphics before loading 
� On-screen grid simplifies text placement 

New in Version 3
� completely re-designed interface
� insert and customize shapes(lines, rectangles, etc.
� insert, place and resize clipart dynamically
� use the Graphics Toolbox to apply special effects
� reads BMP, DIB, PCX, TIF, JPG, and GIF formats
� curved and multiline text
� special text effects like shadowing and outlining
� create/use custom color palettes



INSTALLATION INSTRUCTIONS
If you have not already done so, unzip the archive HL301_SE.ZIP to a temporary directory.  Use File Manager or Windows Explorer to locate and run SETUP.EXE.  This will install all required files and create all necessary icons (menu items in Win 95).



APPLICATION STATUS AND DISTRIBUTION
Home Labeler 3 - Special Edition may be freely distributed under the following conditions:
-  the application must be distributed in its original distribution format, namely a single self extracting archive to be named HL301_SE.EXE.  No modifications whatsoever may be made to this file.
- written permission must be received from Projexis Inc. to distribute Home Labeler 3 - Special Edition on retail racks, in conjunction with any promotion or bundled with any other product.




CONTACTING PROJEXIS
Projexis maintains a full internet presence for those requiring assistance in installing or using Home Labeler.  We can be found at:
E-mail:	info@projexis.ca
WWW:	http://www.projexis.ca



ORDERING THE FULL VERSION
HL3 Special Edition has several features disabled.  Check our website for details on upgrading to a fully registered version.



Thank you for your interest in Home Labeler products.