MooseCap Surveil v.00000001a
January 25, 2000

MooseCap.exe is a simple, free program I wrote in Visual Basic 3.0 utilizing the Capwndx.vbx and Mci.vbx.   I guess I could try to figure out how to thunk it into a 32 bit environment but really what's the difference as it works just fine in Windows 98 and backwards.   Likewise the program is rather small and I like that.   I think all that one needs to use the program is included.  You can simply unzip the files into a selected directory and it will work.   It does for me but if you have trouble let me know by email: sgoff1@tampabay.rr.com.   It requires Vbrun300.dll also (included).

The program captures a few frames of video from whatever default video device is installed on your machine.   You can set the interval of capture from 6 second (.1 min) to any duration in minutes by hitting F3 or the third item on the Options Menu.   Thereafter F1 starts Capturing at that interval, F2 stops Capturing and Ctrl+Q quits.   You will find the short avi files in the application directory into which you installed the program.   They are numbered sequentially by date and time.  None will ever be overwritten.   F4 institutes Preview Mode (as does clicking on the opening or About screen).

By setting your capture device resolution and color depth, the size of each will be determined.   [This is a function of your hardware and must be configured by your accompanying software.]   In 24 bit at 320x240 (my default) each avi is 915 KB.   Thus if you capture every 5 minutes, you'd get about 11 MB per hour.   The capture interval defaults to 5 minutes but any changes you make will be recalled the next time you run the program.

There is a play back and edit feature that allows you to scroll through all the captured videos. The date and time are stamped on each.   You may delete multiple or single files by clicking (with SHIFT or CTRL) and then hitting DEL.   They are gone without confirmation and do not go to the Recycle Bin.   If you wish to archive specific shots, consider winzip or winrar.  I may incorporate a zip feature if there is any interest (eg. Dynazip or something).   I suspect few are interested in support for a 16 bit program so I'll just support myself for now.

If you want the source code, let me know and I'd be tickled to send it your way.   This will save you the effort of decompiling the program which I know is simple and easy to do.  This is my first attempt at a video surveillance program and I realize it needs some work but it is free.

...Warren S. Goff, D.O., FCCP