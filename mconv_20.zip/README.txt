*Multi-Conversion Calculator* Version 2.0

The Purpose of this program is to help/assist you in problems such as converting one unit to another, where you either dont know the conversion number or you have no idea how to do it.  All you need to do is select the conversion you want by selecting a Radio Button next to it, enter the number you wish to convert and Press the Calculate button.

INSTALLATION:
Installing the program is easy, Unzip the file to a Temp directory, goto that dorectory and double click on the MCONV20.EXE File.

THIS SOFTWARE PROGRAM IS *FREEWARE*,  AND YOU MAY DISTRIBUTE IT FREELY AS LONG AS YOU INCLUDE ALL THE FILES


----------------------------------------------------------------
You can send any comments, problems or questions as well as a suggestion for a conversion in up-coming versions, please send an E-Mail to sbouda2000@hotmail.com