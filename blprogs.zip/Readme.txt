===============================================================
	   Four Financial and Legal Software Titles 
	   ----------------------------------------
    Copyright (C) 1994 - 1996 by Business Logic Corporation
    e-mail: e-mail@blcorp.com           Fax: 1-519-763-5483
===============================================================

This file includes four of our software packages. They are as 
follow:

Simply Interest
---------------
Simply Interest is a mortgage and loan amortization and analysis
software package. It will compute almost any type of mortgage
and loan value. This includes loan amount, interest and period.
It will then generate a customizable schedule that can be
printed. The software will also compute bonds, present values,
future values, annuities, financial planning, net present value
and calendar calculations. The program is very easy to use and
allows for unlimted possibilites in calculations. When you need
to compute any time, money or interest related calculations ...
Simply Interest will give you the answers.

FundMaster
----------
FundMaster is a Mutual Fund tracking and analysis software 
package. It will track 10 portfolios with up to 50 funds in
each. It will give you all the stats that you need including
investment in each fund, value of each fund and the exact
compound annual rate of return that you are earning on each
fund. Track your funds with FundMaster and always know exactly
where you stand at all times.

CommonLaw
---------
CommonLaw is a legal document creation software program. Just 
answer the simple fill-in-the-blanks questions that it asks you
on screen and then press a button to create the complete legal
document. You don't need to know any legal jargon. CommonLaw
will create all the common documents that most people will ever
need. This includes Personal Will, Power of Attorney, Bill of 
Sales, Residential Lease, Commercial Lease, Demand Letter etc.

Cricket!
--------
Cricket! is a windows desktop adding machine / calculator. It 
has a scrolling editable tape readout that will instantly 
re-calculate when any of the numbers are edited. The calculator
has so many customization options that you must use it to see
for yourself. It is one of the best calculators of its kind.
Use it and you will agree.

To see more Business Logic Software visit our web site at:

http://www.blcorp.com

For questions or comments on the software, send email or fax to
the above noted email address or fax number. 