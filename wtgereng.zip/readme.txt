Archive Name (e.g. xyz23.zip): wtgereng.zip

Program Name/Title, 25 characters or less (e.g. Super PacNerd): English to
German, Word Translator for Windows

Program Version, 12 characters or less (e.g. 2.01C): 5.3

Program Description (55 chars or less): Automatically translate any text
between English and German.
  Works with any Windows based program including browsers and e-mail
programs. Windows 3.1x, 95/98 and
  NT compatible.

Longer Program Description: Word Translator for Windows is a bilingual
dictionary and
  translation program. Translate individual words and phrases,
  or even complete documents from English to German, or vice versa.
  Add new base words, phrases, and even short sentences to
  the dictionary. Learn new vocabulary and pronunciation.

Does this program require Win32s? (yes/no): No

Is this a demo version? (yes/no): Yes

Suggested directory for placement (e.g. programr/vbasic): archivist choice

If this replaces an older version, name of the old program (e.g. xyz21.zip):

Program Author, 30 characters or less (e.g. John Smith): group of programmers
Company Name (e.g. NetTechies Inc.): Translation Experts Ltd.
Contact Email Address: M.Sirovica@tranexp.com
Contact WWW URL: http://www.tranexp.com
Contact Postal Address:
   42 Walnut Court St. Mary's Gate London W8 5UB United Kingdom
Contact Telephone Number: +385-1-221-980

**********************************************************************
       NOTES: In the space below, please put any special notes to the
archive maintainers (not the program users) about this upload.
**********************************************************************

wtgereng.exe runs under Win 3.1x, 95, 98 and NT. It automatically
recognizes the operating system and installs the appropriate files
during the installation procedure.
