This software creates Websites for Bands.  It includes photo albums, gig schedules, bios, and much more.

To install this software, unzip to a separate directory and run setup.exe.

If you experience any problems installing or running the software, please contact:
	
Kardon Software
sysop@bargainbd.com
(412) 341-4505

This program is shareware and yours to freely evaluate for 30 days.  After that time, it must be registered or removed from your system.
It is freely distributable.