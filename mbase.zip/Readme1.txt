
MemoBase V3.2 SQL driven free form database that allows you to store any type of information and find it very quickly and easily. In use as a knowledgebase for several large companies a copy of the data base can be put on a shared network drive and copies of the front end put on the desktops. Very easy to use ! Ideal as an E-mail holder / searcher.
US$24.00	   for more info e-mail	 info@rlegsoftware.com 
or visit our web site at		 http://rlegsoftware.com
volume discounts.
 R-LEG SOFTWARE.

This copy of MemoBase is Shareware and may be distributed freely. Several extended 
features are enabled upon registration ( See the Help file for more detail ).

Installation:
Unzip memobase.zip into a temp directory and double-click on Setup.exe
This will start the install program which will guide you through the rest of the process.

IMPORTANT:
Due to space limitations on this site, the Visual Basic runtime file needed for this program 
has not been included in this distribution. A complete version of this MemoBase.zip containing all the needed files can be downloaded ( about 800k ) from our site at:
http://rlegsoftware.com. 
or
The run time file vbrun300.dll can be downloaded at this site at:
ftp://ftp.simtel.net/pub/simtelnet/win3/dll/vbrun300.zip
unzip and copy the file to your windows system directory
or
You can search your Windows\system directory for vbrun300.dll