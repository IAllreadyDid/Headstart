		VINNY GRAPHICS 16 bit Version 1.99


INTRODUCTION
Vinny Graphics is a novel graphing and data analysis program for
science and engineering students. It is easy to use and accepts
and exports data through a variety of sources.  The intuitive 
Windows interface helps produce multi-parameter design or test
data graphs and perform simple math operations on groups of cells.
Number inputs can be decimal or exponential with dot or comma
(European) digit separator.  This zip package contains the
complete 16 bit Vinny Graphics application for Windows. If you
wish to run Vinny Graphics on Windows 95/98 you may want to
download the 32 bit Vinny Graphics application for Windows 95/98.
It provides increased speed and allows 21 rather than 12 data sets.  
  
INPUT
Data input is by:
        1-Cut, copy and paste from external spread sheets.
        2-Loading ascii data files in decimal or exponential format.
        3-Key board entry into a series of internal mini spread sheets.
        4-Loading complete graph files.

MATH AND REGRESSION
Data analysis works on up to 21 independent data sets in Windows 
95/98 and up to 12 independent data sets in Windows 3.1x.  Each set
can contain up to 10,000 X,Y pairs.  Results are seen graphically
as changes are made.  Curve fits are 1st to 5th order polynomial,
power,  exponential or log. Simple math operations can be performed
on data in the selected group of cells or data in columns.

GRAPHS
Graphs allow total freedom in setting up scales and grids. Graph
dialogs provide for both automatic selection and manual override.
Log scales with up to 20 cycles for each axis are available.

OUTPUT 
Output is by:
        1-Cut, copy and paste to external spread sheets.
        2-Saving complete graph files or individual data set files.
        3-Saving sizable graph Bitmap files.
        4-High resolution color graph printing.
        5-Complete data set and regression coefficient printing.

FILES IN THE ZIP PACKAGE
This zip package contains the complete 16 bit Vinny Graphics 
application for Windows. It will run on Windows 3.1x.  Three files
are required to run the application.  They are vin16.exe, vin16.hlp
and vin16.cfg.  Put them in the same directory. The demo files may
also be located in this directory or else where. If you desire, the
install.exe file can be run to automate the file transfer process 
and to create a Vinny Graphics Program Group.

ABOUT THE DEMOS
        Logbar.gra demonstrates a 4X4 cycle log-log plot with a
        combination of curve fits, bar and line graphs. This is a
        complete graph and data file produced by Vinny Graphics.

        Demo21.gra and Demo12.gra demonstrate the display of 21
        and 12 data sets.  These are complete graph and data
        files produced by Vinny Graphics.

        DataDemo1.prn is normal X,Y two column data transfer file
        produced by Vinny Graphics.  It represents one data set.

        DataDemo8.prn is an 8 column data file.  The program can
        read but not produce files of this type.  The allowable
        number of columns ranges from 1 to 13 for Windows 3.1x and
        1 to 22 for Windows 95/98. The column lengths ranges from 1 to
        10,000.  Column 1 is loaded as X values. Column 2 is loaded
        as Y values of data set 1 and column 3 as Y values of data
        set 2 etc.  Hint, to see DataDemo8 more clearly use the
        SCALE dialog button FIND ALL after loading.  A complete
        context sensitive help system is included in the program.

MATH SAMPLE PROBLEMS
        The file [math_p.txt] has two sample problems which 
        illustrate the use of Vinny Graphics math operations.
        The first problem is at the introductory level and the
        second is at the advanced level.  The solution to these
        problems are in [math_p1.gra] and [math_p2.gra].

UPGRADE HISTORY
        Version 1.30 adds independent printer output color control
        for each data set.
        Version 1.40 adds independent math operations on data in
        the selected group of cells.
        Version 1.50 adds round off math operation.
        Version 1.60 general font and menu maintenance.
        Version 1.70 Adds decimal format to log scales.
        Version 1.73 Revises help file and fixes minor bugs.
        Version 1.75 Adds total, average and sigma to math menu.
        Version 1.76 Adds three math menu dialogs.
        Version 1.77 Dialog box maintenance.
        Version 1.79 Adds math integration and data duplication.
        Version 1.83 Adds optional automatic scales and grids.
        Version 1.84 Adds optional automatic series titles.
        Version 1.86 Improves navigation with NEXT series buttons.
        Version 1.87 Adds large title font printer option.
        Version 1.89 Corrects scale dialog box problem.
        Version 1.91 Adds toolbar.
        Version 1.93 Adds RPN calculator.
        Version 1.94 fixes calculator shrink problem.
        Version 1.95 allows European (comma) number format as input.
        Version 1.96 adds ten floating titles.
        Version 1.98 adds exit save.
        Version 1.99 adds duplicate & extend data index ie rows.
                     extends range of several calculator functions.

REGISTRATION
The registration dialog will pop up in place of this program when
the free trial period has ended or if you move the program to
a new directory. If this happens try to close and then open the
program and the registration dialog may clear if any free trial
time remains.  If you can not clear the registration dialog you
have two choices. Email the serial number on the top of the 
registration dialog to email address below and request a two week
extension to the free trial period or mail in the serial number
with $10.00(US) to the mail address below and request a permanent
registration code.  If you include a stamped self addressed
envelope you will receive an activation code by mail or by email
if you include your email address. Be sure to include your serial
number with your request. If you wish to register prior to your
free trial time running out, the registration dialog can be found
under the HELP menu item. Upgrades are available free to
registered users just send the new serial number to the email 
address below.
 
ABOUT THE AUTHOR
The author is a retired engineer.  He lives in Manchester,  Ct.
If you have any questions or comments,  contact him at one of the 
addresses listed below.  

MAIL ADDRESS
Vincent J. Sansevero, Jr.
71 John Olds Drive Apt 207
Manchester, Ct 06040

EMAIL ADDRESS
vsansevero@earthlink.net

HOMEPAGE URL
http://home.earthlink.net/~vsansevero/

