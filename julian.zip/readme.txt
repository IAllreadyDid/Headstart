Julian v1.2 * Gregory Kwok <gkwok@jps.net>

This is a command-line utility that converts regular calendar dates into
Julian dates (Jan 1 = 1, Jan 2 = 2...Feb 1 = 32, etc.).

For brief instructions on command line switches and syntax, type
  JULIAN /?

Usage: julian [/r] [month] [day] [year]
Examples:
  julian /?          : Display this help message
  julian             : Julian date for today
  julian 7           : Julian date for the 7th of this month
  julian nov 11      : Julian date for November 11 of this year
  julian 6 18        : Julian date for June 18 of this year
  julian 5 23 2001   : Returns 143, also accepts "julian may 23 2001"
  julian /r 149      : Returns May 29, or May 28 for a leap year
  julian /r 233 1996 : Returns August 20, 1996

This archive contains both 32-bit and 16-bit executables, as well as source
code. The 32-bit version was compiled with DJGPP 2.01; the 16-bit version was
compiled with Borland Turbo C++ 3.0.

This program is shareware. Please distribute it freely. If you make any
modifications to the source code, please contact me.

Contact information:
  Gregory Kwok
  gkwok@jps.net
  http://www.jps.net/gkwok/