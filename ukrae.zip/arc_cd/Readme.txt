Using the downloaded file

Use "Extract to.." in your archive extraction software to place the site where you want on your computer

To use the project, navigate to the RAE CDROM folder and open "index.htm". You may wish to create a shortcut, menu item etc to point to the file.

The file "Autorun" if for CD use only and has no effect in this type of installation 



Creating a CD

Navigate to the "RAE CDROM" folder and select all files

Burn the CD in the normal way

Note the CD should contain the contents of "RAE CDROM", not the folder itself


Using the CD created above

The CD should start automatically. If it does not, open the file "index.htm"


In case of difficulty visit http://www.ukradioamateur.org

