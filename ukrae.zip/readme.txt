This file-set and all it's associated contents �2001-2003, Amateur Radio Course, all rights reserved


Using the downloaded file

Use "Extract to.." in your archive extraction software to place the folder containing the
files where you want on your computer

To use the project, navigate to the folder and open the file "start.htm".
You may wish to create a shortcut, menu item etc to point to the file.

The following files are for CD use only and may be discarded
	Files - autorun.inf, autorun.ico, start.exe, start.ini
	Folder - menubox



Creating a CD

Navigate to the folder and select all files

Burn the CD in the normal way

Note the CD should contain the contents of folder, not the folder itself

The CD should contain the following items at the root (top-level) directory

	Folders:menubox
		arc_cd		

	Files:	autorun.inf
		autorun.ico
		start.htm
		start.exe
		start.ini
		readme.txt

Ensure that the CD burning software has not changed the filenames to uppercase.

CD should be ISO9660 Level 2, Mode 2/XA with Joliet secondary descriptor enabled.




Using the CD created above

The CD should start automatically. If it does not, open the file "start.exe"




In case of difficulty visit http://www.ukradioamateur.org

