
Memotest is a memory test program. To install it run setup.exe. 
Memotest is a Freeware software, and it is freely distributable.
In case of any questions or problems, please contact us at mnemonist@yxo.com.

