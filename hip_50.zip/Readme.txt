Hippie HTML Editor Version 5.0
4-8-98
readme.txt

Notes:
======

Hippie allows you to edit HTML files for use on the Internet.
It is distributed as Shareware: you can try the product freely 
but you must register it to have access to all of it's features.

You can register the software at: http://www.hippie98.com

Technical Support is available at: support@hippie98.com

If you have downloaded the .zip file, unzip into a temporary
directory, and run setup to install.

Recommended hardware: 256-color or better super VGA,
   640x480 or 800x600 or 1024x728 screen size,
   Windows smartdrv.exe, an Intel486(TM) 33MHz processor or faster, 
   4 MBytes or more of RAM.

--------------------------------------------------------------
LICENSE AGREEMENT
=================
  Trout Software ("Trout") grants you an exclusive single-use
  right to use this software program (the "Software").

  You will not reverse engineer, decompile, or dissassemble the
  Software. 
  The Software is copyrighted.  You may not remove the copyright
  notice from the Software.

  LIMITATION OF WARRANTY AND DISCLAIMER OF WARRANTY:

  The Software is provided "AS IS" without warranty of any kind.
  Further, Trout does not warrant, guarantee, or make any
  representations regarding the use or the results of use of the
  software or documentation in terms of correctness, accuracy,
  reliability, currentness, or otherwise.  The entire risk as to
  the results and performance of the Software is assumed by you.

  The above is the only warranty of any kind, either expressed
  or implied, including but not limited to the implied warranties
  of merchantability and fitness for a particular purpose, that 
  is made by Trout on this Software.
  ----------------------------------------------------------------

