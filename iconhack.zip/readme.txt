About box
=========

No setup folks...these are dev tools; you should know how to
use this stuff.  The EXEs can be used as-is.

Nuke the memo...this is for your eyes only as a developer.
This project is provided as-is as a means of manually hacking
cons in compiled exes and dlls. The back end for this is courtesy
of "Phideaux", a.k.a. William Brooks.  Front end is by "WinterHeat",
a.k.a. Cub Lea.  The idea for the icon display listbox came from
an anonymous code pack called ICONTRAP.

The save-as-bitmap code isn't implemented...it's simple enough
to complete.  It does not palette the icon bitmap to 16 colors on
save unless the system is configured for 16 colors.
Everything else should be fully functional.

This utility is nastyware...it was created out of necessity
due to a set of circumstances I am not even at liberty to discuss.
Let's just say that someone's ego cost me a lot of time and money.

This package also contains Icon Whack, generously offered up by
Mitch Howard as freeware.  TBOMK its source was never made widely
available.

And for your convenience, the 32 bit source (sorry...not 16 bit
compatible) of ConvertIcon (to BMP) is included, sans compiled
.EXE...it has its own docs.

Both are in their own subdirs.

Uploaded by Cub Lea (cublea@radiant.net). For a peek at what I do,
check out ORDER.HLP.

Copyright restrictions:
======================
The code and implementation is free for you to use. As a courtesy
I would appreciate it if the look and feel were changed prior to
using this set of units in any commercial, shareware or freeware
project. The helpfile is mine...write your own or *ruthlessly* edit
my text.  If you steal either the text or the layout for a look-alike
app, you'll hear from me via someone who gets paid more per hour than
I do, and it'll be my publisher you'll hear from, not me...understood?

That out of the way, let's get down to it.

Stuff:
=====
The project uses DTools' balloon hints. Nuke the reference
in favor of your own multiline or custom hint component.

This is Q&D stuff here, designed for a specific application
and it's nowhere near an icon hacking utility for all
purposes. This archive also includes Mitch Howard's freeware
C code and icon hack executable which might suit your needs
even better.

Consider the disclaimer screen essential to prevent mailbombs,
death threats and damage suits.

Known limitations:
=================
Since this was designed for a proprietary application, its
functionality is somewhat limited but the tools for extending
it exist in Neil Rubenking's ICONJACK source code available 
from the ZDNet archives.

It will not accept icons in source or target which have
been compiled into resources using integer IDs as opposed to
text IDs. It chokes on any non-766-byte standard icon. That means
just about anything Microsoft is going to be invisible until its
icons are saved individually and reloaded into the browser. An
easy fix for someone who knows what they're doing...why it isn't
fixed here says plenty about my workload.

Warn your users about copyrights on iconic images!!! Failure to 
do so could land you in court.

Cub Lea
Sept. 9/97
