                                   README

Business & Finance Multilingual Dictionary

                   - <Company_Info>
  <Company_Name>I. Sharshakov dba Author</Company_Name> 
  <Address_1>15-10 Levkov Street</Address_1> 
  <Address_2 /> 
  <City_Town>Minsk</City_Town> 
  <State_Province>BY</State_Province> 
  <Zip_Postal_Code>220007</Zip_Postal_Code> 
  <Country>Belarus</Country> 
  <Company_WebSite_URL>http://www.authorsden.com/sharshakov</Company_WebSite_URL> 
- <Contact_Info>
  <Author_First_Name>Igor</Author_First_Name> 
  <Author_Last_Name>Sharshakov</Author_Last_Name> 
  <Author_Email>sharshakov@authorsden.com</Author_Email> 
  <Contact_First_Name>Igor</Contact_First_Name> 
  <Contact_Last_Name>Sharshakov</Contact_Last_Name> 
  <Contact_Email>sharshakov@authorsden.com</Contact_Email> 
  </Contact_Info>
- <Support_Info>
  <Sales_Email>sharshakov@authorsden.com</Sales_Email> 
  <Support_Email>sharshakov@authorsden.com</Support_Email> 
  <General_Email>isharshakov@yahoo.com</General_Email> 
<Keywords>dictionary, glossary, 9984921735, sharshakov, ebook, language, translate, foreign, multilingual, business, finance, banking</Keywords> 
  <Char_Desc_45>Translate business & finance terms btw 4 languages</Char_Desc_45> 
  <Char_Desc_80>Ideal for any business traveler covering terms in four principle languages.</Char_Desc_80> 
  <Char_Desc_250>This dictionary contains an extensive vocabulary, covering a wide range of topics relating to business - from office practice to stock market and accounting terminology in four principle languages - English, German, French, and Russian.</Char_Desc_250> 
  <Char_Desc_450>This dictionary contains an extensive vocabulary, covering a wide range of topics relating to business - from office practice to stock market and accounting terminology in four principle languages - English, German, French, and Russian.</Char_Desc_450> 
  <Char_Desc_2000>Ideal for any business traveler covering terms in four principle languages. This dictionary contains an extensive vocabulary, covering a wide range of topics relating to business - from office practice to stock market and accounting terminology in English, German, French, and Russian. For home, school and office. Quick and easy to use. Authoritative, up-to-date definitions. Extensive cross referencing. Totally modern vocabulary. Powerful browse & search capabilities. From international to personal business and finance.</Char_Desc_2000> 