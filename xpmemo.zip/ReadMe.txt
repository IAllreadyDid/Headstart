Info's about XPress Memo V1.0
*****************************

XPM is FreeWare.
XPM is an Application to manage Memo Informations.
It runs on Win 3.X, 95, 98 and NT.
It was conceived for PC and Notebook use.
It has no Sound or Video so you can play any kind
of Multimedia Files in a new Window.
When you overwrite your TextData press "Save"
and then "Refresh" to compare the old with the
new Data.
Place a Shortcut of XPM to the Autostart Folder
to run XPM at StartUp.

*If you like it you can send a few money
*to the following adress to help me making more
*FreeWare Products-Thank you.
*You can also tell me what you like or dislike
*towards this program this helps me to enhance it.
*From time to time new versions of it will appear.
*Ideas for new Freeware Applications are welcome.
 
 Alexander Mauder
 Am Erlenberg 8
 D-64354 Reinheim
 Bundesrepublik Deutschland / Germany
 mach10jet@hotmail.com

Requirements:
************

This Program requires VBRUN300.DLL which is not included
because of its size. It is available from Simtel.Net as
VBRUN300.ZIP from the following emplacement:
ftp://ftp.simtel.net/pub/simtelnet/win3/dll/
It is also available from many on-line services and BBSs.
 
Note: This Freeware runs with 256 Colors
      and higher.
      For 640*480 run XPMemo64
      (Runs also with 640*480 16 Colors)
      For 800*600 run XPMemo86
      (Runs also with 1024*768 and up)

Alexander Mauder July 1999
