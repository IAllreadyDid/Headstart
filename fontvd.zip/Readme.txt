

Please not that the unregistered version will not print!
Also note that version 1.04 is a beta copy and version 1.05 
will be available on our website on on the forum you uploaded this from
on 3/1/97. Version 1.05 will not be beta.
Please contact us if you find any problem you may visit our web site
"Bug Report" at http://members.aol.com/qikneasy