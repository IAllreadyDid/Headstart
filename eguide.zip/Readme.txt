                 Readme for PlanWare eGuides
                 ===========================

			Contents
			========

	1.	Introduction to eGuides
	2.      Installing/Uninstalling eGuides
	3. 	Using the eGuides
	4.	Other Business Planning Help
        5.      Ombudsman Statement
        6.      Revision History
        7.      Contact Details

##############################################################
CAUTION: 
If you acquired the eGuides from an unknown third-party, 
we recommend that you check the file EGUIDE.EXE for viruses
before loading it. This message is intended to encourage safe 
computing practices and should not be a cause for alarm.

##############################################################
1. Introduction to EGuides
##############################################################

The PlanWare eGuides comprise a series of "white papers" on
business planning matters which have been compiled as a 
self-contained executable file.

The eGuides are presented as a series of web-style pages which 
can be viewed on-screen or printed on 60+ pages. They 
cover the following main topics:

	Getting New Business Ideas
	Devising Venture Strategies
	Developing a Business Strategy
	Writing a Business Plan
	Preparing Financial Projections
	Making Cashflow Forecasts
	Managing Working Capital

They have been based on some of the white papers at the 
PlanWare site <http://www.planware.org>. This site specializes
in tools for writing business plans, making financial 
projections, business planning and developing business 
strategies. These comprise software, shareware, freeware, 
white papers and other useful features & on-line resources. 
They are aimed at managers, professional advisers, business 
owners, entrepreneurs, start-ups and established businesses 
of all sizes.

The PlanWare eGuides are copyright. You are free to print a
single copy of an eGuide for personal use provided it remains
complete and unmodified in all respects. The printing of 
multiple copies in whole or part is not permitted. 
See LICENSE.TXT.

The PlanWare eGuides are freeware. If you find the eGuides
useful, it is permissible to distribute copies of the 
EGUIDE.ZIP archive file to colleagues and associates. See 
LICENSE.TXT for more info.

Send queries, comments and distribution permission requests
to <eguide@planware.org>. If requesting permission for 
commercial distribution, please specify the scale of 
distribution, method to be used, context and target audience 
as well as background information on the requesting 
organisation (suppply a website address).

##############################################################
2. Installing/Uninstalling eGuides
##############################################################

The supplied archive file contains the following files:

		eguide.exe
		readme.txt (this file)
		license.txt
		eguides.htm (used for freeware distribution)
		eguides.xml (used for freeware distribution)
		file_id.diz (used for freeware distribution)

To access and use the eGuides, unzip the archived files into 
a new folder ("eguide" is a suggested name) and then run the 
executable file EGUIDE.EXE. This will immediately load the 
eGuides - that's it !. 

User registration is not required and the eGuides do not
modify your PC's system during installation. 

To uninstall, simply delete the unzipped files.

##############################################################
3. Using the eGuides
##############################################################

The eGuides contain a series of web-style pages which address 
the various planning topics. These pages incorporate hyper-
links within and between eGuides as well as external links to 
the PlanWare site. To check whether links are internal or 
external, turn on the Status Bar via the View menu - external 
links start with http://www.planware.org and require an 
Internet connection.

Toolbar and menu options within the eGuides perform the 
following functions:

* To print a single eGuide, use the File | Print menu or Print 
button. Note: If printing an entire eGuide, select Print range
All. Typically, an eGuide will print on 8-12 sheets. 

* To print all the eGuides, use the File | Print All menu 
option. Note: This process will use about 70-80 sheets. 

* To navigate between eGuides, use the Go menu, Home, Back 
buttons or select from the Page dropdown list. 

* To search within eGuides, use the Edit | Find option. 

##############################################################
4. Other Business Planning Help
##############################################################

The PlanWare site <http://www.planware.org> contains extensive
assistance on business planning and related matters. 

It offers shareware and commercial software packages for
preparing business plans, making financial projections and
assessing business ideas including:

  - Exl-Plan range of shareware business financial planners
    for use with Excel.
  - Plan Write range of business plan writers.
  - Insight range of software for evaluating business ideas
    and strategies.
  - On-line financial planner.
  - Online strategic planner.

... and much more.

##############################################################
5. Association of Shareware Professionals Ombudsman Statement
##############################################################

Invest-Tech, author of eGuides, is a member of the
Association of Shareware Professionals (ASP).

"ASP wants to make sure that the shareware principle works for
you. If you are unable to resolve a shareware-related problem
with an ASP member by contacting the member directly, ASP may
be able to help. The ASP Ombudsman can help you resolve a
dispute or problem with an ASP member, but does not provide
technical support for members' products. Please write to the
ASP Ombudsman at 157-F Love Ave, Greenwood, IN 46142 USA,
FAX 317-888-2195, or send email to omb@asp-shareware.org."

##############################################################
6. Revision History
##############################################################

September 2000
--------------
eGuides v1.0
First general release freeware version.

##############################################################
7. Contact Details
##############################################################

Contact details for the author of eGuides are as follows:

	Invest-Tech Limited
	27 Ardmeen Park
	Blackrock
	Co Dublin
	Ireland

	Tel: + 353-1-283 4083
	Fax: + 353-1-278 2391
	(Replace + by international access code)

	E-mail: info@planware.org
	Web: www.planware.org

##############################################################
End of Readme






 

