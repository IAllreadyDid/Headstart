Program Name:		wedplnr.zip
Program Purpose:	Easy to use Windows 3.1 and Windows 95 software program that
			assists in planning a wedding.
Installation:		Unzip archive into a temporary directory.  Run the
			program setup.exe from the temporary directory.  Follow
			the instructions outlined in the setup program.
Program Status:		Shareware.
Distribution Status:	Freely distributable as long as the entire archive is
			distributed.
Contact Information:	email: cowles@deltanet.com or (714) 703-2350.