PROGRAM PURPOSE
---------------

Solutions is a mathematical windows software built for engineers and
scientists. It is powerful yet easier and more flexible to use than your
standard or your RPN calculator. Solutions will provide you with 20 classes
of function from Algebra to Statistics. It will plot and print your work.
You can even program it if you need more power!

Solutions will do quick work of your calculations. All Solutions' functions
work with both symbolic and numeric data. Numeric data can be real or
complex numbers, as well as vectors and matrices.

You work interactively with Solutions as with a calculator (but it is much
more powerful) so you will use it within minutes. Solutions fully supports
algebraic computations. For example, you can instantly compute the
derivative of any equation. The answer is given to you directly or one
step at a time so you see all the intermediate results.

Should you need it, Solutions' programming language is simple to learn and
will provide you with even more power for solving complex problems. It is
a much quicker and efficient alternative than FORTRAN, BASIC or C.

INSTALLATION
------------

See install.txt for installation instructions


PROGRAM STATUS
--------------

Solutions is FREEWARE and may be distributed WITH WRITTEN PERMISSION
from the authors.  They may be reached at elan@clic.net.


Also see the Solutions web site:  http://www.qbc.clic.net/Elan (Please mind
the capital "E")

Solutions is copyright (c) 1996 by Elan Software.
