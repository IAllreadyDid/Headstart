About Time=Money
----------------
Do you have too many things to do and too little time to do it? How
many of us wish that we have more than 24 hours a day to do all the
work needed. Time=Money is a money timer and helps you prioritise your
work.

Installing Time=Money
---------------------
Thank you for evaluating Time=Money.

This version of Time=Money is designed for Win3.1. As such, you will
also be able to install on Win95 and WinNT.

If you have yet to run setup.exe, do so now as it will create the 
necessary icons and program group.

You have 30 days to evaluate this program after which you msut order
the registered version (see instructions below) if you want to continue
using the program. In the unlikely event that you find the program not
useful (if the program can save you half an hour a week, it would pay 
for itself many times over), you must remove the program from your 
computer. Just delete the C:\Timoney directory.

Your comments on how the program can be improved are always welcomed. 
In fact, the next version of the software is free if your suggestion 
is adopted in the program. 

Contact Information
-------------------
Company Name : EmAnt Data
home page    : http://web.singnet.com.sg/~emant
email        : emant@post1.com
address      : 10 Anson Road, #33-17 International Plaza 
               Singapore 079903
Tel          : (65) 5657908
Fax          : (65) 5659776

Distribution of this shareware
------------------------------
This shareware version of Time=Money is freely distributable. 

Time=Money Order Form
---------------------
To order Time=Money, please fill out the form below and fax to us. 
Email is best. 

There are two ways to obtain your Time=Money:

1) If you have an evaluation copy of Time=Money, select registration 
(under delivery method) in the order form. Your registration 
information will be either fax or emailed to you the next working day. 
Follow the registration instructions and you will have a licensed copy
of the program. This is the fastest and also the cheapest method.

2) Select diskette (under delivery method) in the order form. Your 
order will be acknowledged but shipment of the product will only be 
made after payment is received. Allow 1-3 weeks for delivery. 

Prices
------
For Singapore orders only

The price is S$10 per copy. You could pay either by personal cheque or 
postal order.

For orders outside Singapore

The price is US$7 per copy. Payment should be by cashier or postal 
order. 

If you wish to receive the diskette version of the software, please add
US$3 (for orders outside Singapore) for postage and handling. 

Quantity orders

Quantity discounts are available for orders exceeding 100 in quantity. 
As Time=Money is great as a gift for prospects and customers, we will 
also customise Time=Money to display your company's logo and contact 
information for orders exceeding 100 copies. Please contact us for 
more information.

Payment Instructions
--------------------
Please make out your payment to EmAnt Data

And send your payment to 

EmAnt Data 
10 Anson Road, 
#33-17 International Plaza, 
Singapore 079903 
Republic of Singapore

For all orders, please DO NOT SEND CASH

ORDER FORM
----------
NAME:     ______________________________
TITLE:    ______________________________
COMPANY:  ______________________________
ADDRESS:  ______________________________
          ______________________________
CITY:     ______________________________
STATE:    ______________________________ ZIP:  _______
COUNTRY:  ______________________________
PHONE:    _____________
FAX:      _____________

QUANTITY: _____
OPERATING SYSTEM:    Win 95/NT __  Win 3.1 __ (Please tick one)
DELIVERY METHOD : Registration __ Diskette __ (Please tick one)

