RATE CALCULATOR 1.0
**********************

Rate Calculator is designed to help contractors work out how much
they should be chargeing there employees based on taxes, agent, skill ect.

To install Rate Calculator copy all of the files contained in
the ZIP file to c:\ratecalc or simalar, then run RATECALC.EXE
to start the program

THIS PROGRAM IS FREEWARE PLEASE DISTRIBUTE IT!

Any question's or comments can be E-Mailed to -

Beasley@Labyrinth.net.au

or by mail to 

BazCORP Software
25 Gowar ave
Camberwell, Victoria
Australia, 3124

or by fax to

61 3 9889 0561


To install Rate Calculator copy all of the files contained in
the ZIP file to c:\ratecalc or simalar, then run RATECALC.EXE
to start the program