      ,gg,                      ,gggggggg,
     i8""8i                    d8P""""""Y8b,
     `8,,8'                    88,_a     `8b
      `88'     gg              `Y8P"      88
      dP"8,    ""                         88
     dP' `8a   gg     ,gggg,gg           d8'     ,gggg,gg    ,gggg,gg
    dP'   `Yb  88    dP"  "Y8I        _,d8'     dP"  "Y8I   dP"  "Y8I
_ ,dP'     I8  88   i8'    ,8I      d8888ba,   i8'    ,8I  i8'    ,8I
"888,,____,dP_,88,_,d8,   ,d8I          "Y88b,,d8,   ,d8b,,d8,   ,d8I
a8P"Y88888P" 8P""Y8P"Y8888P"888         ,d8888P"Y8888P"`Y8P"Y8888P"888
                          ,d8I'       ,8P"  88                   ,d8I'
                        ,dP'8I       d8'    88                 ,dP'8I
                       ,8"  8I      d8'    ,88                ,8"  8I
                       I8   8I      88     d8'                I8   8I
                       `8, ,8I      Y8,_ _,8P                 `8, ,8I
Version 2.1             `Y8P"        "Y888P"                   `Y8P"

Thankyou for downloading SigZag!

This program will help you create your  own  personalized  signature
quickly and easily.  There are almost 7,000 pieces of ascii art  for
you to choose from - including animals, comics, and just  about  any
thing else!  It also allows you to  use  thousands  of taglines, and
there are 135 figlet fonts -which create ascii text like that above.

SigZag won't only help you create an excellent signature... you  can
also use it to create entire ascii  texts,  allowing  you  to  embed
pictures throughout emails et cetera.

Have a look at "The Great Ascii  Art  Library"  while  your  online, 
 http://www.geocities.com/SouthBeach/Marina/4942/ascii.htm.  Theres
dozens of links to ascii related websites and programs. You can also
download updates to SigZag, and any new libraries or fonts.

Include with this package are two  more  programs.   "Sliver"  is  a
utility which will let you quickly search through all the ascii  art
included with SigZag, and copy the art you want.  You will also find
"Sled" - SigZag's Library Editor.  This utility will let you  create 
your own custom SigZag libraries to distribute.  You will be able to
create libraries of ascii art which will let you access any piece of
art you want instantly!

** NOTE: This program requires VB40016.DLL.  If you don't  have  it,
you may download it at SigZag's website:
http://www.geocities.com/SouthBeach/Marina/4942/sigzag.htm

====================================================================
====================================================================
This program is freeware. It may be distributed freely with the only
  exception being that all original files are included unmodified.
====================================================================
====================================================================
To Install

Installation is easy - Just click on  setup.exe.   The  default  and
recommended directory is c:\SigZag.

====================================================================
Known Bugs

* The main bug I know about, (and am working  on),  is  that  SigZag 
  won't display individual graphics greater then 1  kilobyte.   Now,
  this is an error in the  programing  language  I  have,  since  it
  should be able to go up to 2kb (which incidentally is exactly what
  we need!!!) - But it won't! :(

* 'N16.DLL' ERROR

Apparently, our good 'ol friends at Microsoft decided to change  one
of the files required by many programs to fit M$'s needs. If you get
any error complaining about some 'N16.DLL' then this is the problem.

Solution?:  I've been told you can try downloading the previous DLL,
and it should work.  Find it at SigZag's homepage, and I  think  you
can unzip it into your SigZag directory.

    http://www.geocities.com/SouthBeach/Marina/4942/sigzag.htm

====================================================================
Reporting Bugs:

I would greatly appreciate it if anyone could tell me  any  bugs  ye
have found.  Make sure you tell me your operating system and so  on,
and of course, as much about the bug as you can.

====================================================================
W H A T ' S    N E W
--------------------------------------------------------------------
VERSION 2.0
* Made SigZag mould itself to the current screen size.
* You can now resize the work size of the signature (ie greater then
  the screen size).
* There's now a previous file list in the file menu.
* Added better 3 dimensional controls.
* Added unmodify, and unmove options.
* Improved graphic editor in SigZag.
--------------------------------------------------------------------
VERSION 1.4
* Added the ability to have multiple undos.
* Added the option to turn off the splash screen for registered users.
--------------------------------------------------------------------
VERSION 1.3
* Fixed up a bug in Sled - Deleting the  2nd  category  crashed  the
  program and made the library unreadable.
--------------------------------------------------------------------
VERSION 1.2
New in SigZag:
* New choices in file menu to open SigZag's Library Editor,  and  to
  show the current signature in notepad.
* New choice in Add menu to draw in your own art.
* New section in help file showing the Hotkeys.
* New section in help file - A tutorial for sled.
* Added <shift+right mouse button> hotkey to copy a graphic.

Bug Fixes:
* There was a small bug in the Zag signature file where characters
  sometimes went missing.
* When editing pictures (in SigZag and Sled), just entering a few 
  spaces crashed the program. Doh!
====================================================================
         You can contact me at: james.dill@technologist.com
                 I hope you enjoy this program.
====================================================================