
International House Plans v97 is a example of our house designs rangs.
Used to help the new home buyer choose a house designs to suit they
needs.A easy to use home catalog that let you select a home or give new 
the ultimate house design.Also includes house Designs of the FUTURE
and lets you order the full version or plans ready for Building.


Special requirements: None.

Changes: Additional features added.

yourp210.zip has replaced yourp209.zip.

Shareware.  Uploaded by the author.

Regards,
Chris Morris
-----------------------------------
CLM International
Email:   cam@onthenet.com.au
http://www.exp.com.au/designs.htm
-----------------------------------
