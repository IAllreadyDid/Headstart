1. The purpose of the program.
Scgem is a simple yet easy to use spreadsheet like calculator.
Besides the normal values and text entries, you can reference cell
address and use built in formulas as Min/Max, SumX, SumY or enter
formulas inside the cells. You can insert as well as delete rows and
/or columns. Help is available with ?.
Program utilizes GEM graphic routines (under GNU GPL) and comes with
a full single exe installer. It also contains full source code in 
Turbo Pascal 4 or higher (need gempas library, do an ftp search...)

2. How to install the program.
To install, unzip the Archive and start scgem.exe - the single install exe.
The installer will only place all files in the \gemapps\gemsys directory!
It will automatically insert an entry in the programs folder and also
has complete uninstall feature!

The scgem.zip Zip Archive contains:
readme.txt	-	this text.
scgem.exe	-	single file installer with uninstall option.

3. The status of the program
Scgem is under GNU GPL Version 2.0 or later.

4. The distribution status of the program.
Freely.

5. How to contact the author
Mail:	peter.sieg@gmx.de
Web:	www.petersieg.de


