SIGHTS & SOUNDS for Windows
CopyRight 1999 - Doug Scott
E-mail:   scotware@visto.com
Web:      www.scotware.8m.com     
          

     Sights & Sounds is a video cataloging/organizing system designed to run on any version
of Windows.  This is a shareware program which may be freely distributed provided that it is in
its original form (sights.zip) and has not been altered in any way.

INSTALL/UNINSTALL:

     There are two files contained in the file Sights.zip: readme.txt and govideos.exe(self
extracting archive/automatic installation).  After unzipping Sights.zip, run the file govideos.exe
to install Sights & Sounds.  All files are placed in the same directory/folder.  There are no hidden
or system files files created.

1)   New users should place Sights & Sounds into its own directory/folder.

2)   Those upgrading from the DOS version of Sights & Sound:

          A)  You can install Sights & Sounds for Windows into the same directory/folder
as your DOS version. The program automatically detected your DOS version registration
number.  It is not necessary for you to re-register, but you should e-mail me to let me know you
have upgraded.  If you like Sights & Sounds for Windows and wish to keep it, you can delete the
following files that are used with the DOS version only: CONFIG.DAT, PRINTER.CTL,
SSVIDEOS.EXE, SSVIDEOS.HLP & SSVIDEOS.TXT.   If you'd rather use the DOS version,
DO NOT USE THE UNISTALL option!  It will also delete your DOS data files!  Manually
delete the following files:  BACKUPIT.DLL, BACKUPIT.EXE, CW2CLA16.DLL,
CW2RUN16.DLL. SASWIN.EXE, SASWIN.HLP & the subdirectory folder called "uninst".
     
          B)  you can install Sights & Sounds for Windows into its own directory/folder
(recommended) and then copy the following data files from the DOS version directory to the
Sights & Sounds for Windows directory/folder:  VIDRATES.DAT, VIDRATES,K01,
VIDREG.DAT, VIDSTARS.DAT, VIDSTARS.K01, VIDTAPES.DAT, VIDTAPES.K01,
VIDTAPES.K02, VIDTAPES.K03, VIDTAPES.K04, VIDTAPES.K05, VIDTAPES.K06,
VIDTAPES.K07, VIDTAPES.K08 & VIDTAPES.K09.  After doing this, your copy of Sights &
Sounds for Windows will automatically detect your DOS version registration number.  It is not
necessary for you to re-register, but you should e-mail me to let me know you have upgraded.  If
you'd rather use the DOS version, you can safely use the uninstall option to delete all the Sights
& Sounds for Windows files.


Thank you.
