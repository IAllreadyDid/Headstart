Datarec Shareware Version 1.10.02 Release Notes.
August 1998.

Program Name:					Datarec - The Ultimate Database for Popular Music Management.
Operating System:				Windows 3.1 or higher
Version:							1.10.02
Recommended BBS filename:	DATAREC.ZIP
Release Date:					August 1998
Registration:						�22.00 + �3.00 p&p (�5.00 for overseas orders)

Product Descriptions:
Short: Music database for cataloguing and maintenance of a music collection.

Long
Windows database specifically designed for the cataloguing of various aspects of recorded music media. Features include:- easy to use interface, drag and drop, unlimited database file size, read album & track times directly from CD-ROM, print in colour, complete range of search and select options. You can also create cassette inlay cards, cassette face labels, recording lists, comprehensive catalogues/reports with on-screen preview, specify your own music formats and export options are also included.

Datarec Features.
Build-in Automatic Formatting options Like - Taking 'The' or 'A' form the beginning of an entry and attaching it to the end. For example The track 'The end of the innocence' would become 'End of the innocence, The', or the track 'A walk in the park' would become 'Walk in the park, A'. When it comes to sorting your data, these options help to spread out all tracks beginning with 'The' or 'A'.

Also, Initial Capatilisation of Album, Track and Performing Artists fields, as well as an option to automatically capatilise the first character of each word in these fields - All options can be switched on or off.

You've also got the option to Reverse these formatting effects when creating reports, J-Card inserts or Recording Lists. Our example track above would be resored to it's original appearance 'The End of the innocence'

Intuitive easy to use interface.

Size of database files only limited by disk space available on your computer.

Effortlessly create Cassette Inlay Cards (index/J-Cards) for you cassette cases, by dragging tracks from the database and dropping them onto the Inlay module.

Full control over typeface information (including colour) for Inlays and reports. If you have a colour printer, use it to full effect within Datarec.

Print Face Labels for your tapes / cassettes and Divider Cards for your compact disc's / cassettes.

Create your own Recording Lists easily by dragging tracks from the database and dropping onto the Cassette Recording List dialogue. This helps to insure that when you are recording a tape, tracks are not cut short at the end of each side.

Create comprehensive catalogues / reports (pre-defined and customisable).

Preview reports on screen before printing.

Print just the selected pages that you require from within a report.

By using a CD-ROM drive, you can read album information directly from CD - number of tracks, running times etc. Saves a lot of input time!

Specify you own particular Media formats � Reel to reel, DAT, 8-track, 78's! and not forgetting that old classic� LP.

Effectively search the database for information that you require. You can also save your most frequently used searches for instant recall again and again.

Comprehensive range of sample files to get you up and running with Datarec.

Complete on-line documentation available at  the touch of a button or the click of a mouse. Whichever is the quicker.

Export data to ASCII text files - Allowing you to bring the information into other packages.

Transfer album information between computers using Exchange Data Format Files, or directly from one database file to another.

Installing Datarec.
NOTE: If you use a virus protection program or have any other programs running on your computer, close them down before using the Datarec Set-up program. The Set-up procedure may not function correctly with other programs loaded into memory. Once installed your can safely run other programs along with Datarec.

From Program Manager
�	Start Microsoft Windows.
�	Insert the Datarec 'Disk One - Set-up' into drive A: or B:
�	From the File Menu in Program Manager, choose Run.
�	Enter a:\setup or b:\setup in the dialogue box which appears on screen.
�	Click the OK button or press ENTER.
�	Follow the Set-up Instructions below.

From File Manager
�	Start Microsoft Windows.
�	Insert the Datarec 'Disk One - Set-up' into drive A: or B:
�	Open File Manager by double-clicking on its icon.
�	Select the toolbar icon representing the required drive A: or B:
�	On the right hand side of the screen is the file list, locate and double-click on the filename 'SETUP.EXE'.
�	Follow the Set-up Instructions below.

Set-up Instructions
Following on from whichever procedure used above, you will then be asked to:-

�	Supply the destination directory in which you want Datarec installed. The default directory is C:\DATAREC, but this can be changed to another directory if the default is not suitable.
�	Click Continue to move on.
�	You will be prompted to insert the remaining disk(s) as and when needed. Just insert the required disks clicking the OK button each time to continue.
�	Set-up will then create a Program Manager Group containing the Datarec Program Icon. To start Datarec, simply double-click on the icon and the application will load.

Starting-up Datarec.
If you are in DOS, start Microsoft Windows by typing Win at the DOS C:> prompt, then press
[ENTER]. This will load the Windows Operating Environment.

Once Windows is loaded, locate and double-click on the Datarec icon. A start-up screen should
then appear, and after a short delay two buttons will then be displayed, Click the Continue button to
proceed.

At this stage the majority of commands will not be available until a database has been opened.
Before proceeding to open a database you should view Navigating the Datarec Menu Structure for a
short note about the various options avaiilable to you.

Version History.
See accompanying help file for complete history of changes to TapeMate.

If you need to contact the author for whatever reason you can do so by sending email to stevo@elvaronms.com. Alternatively, you can write to:-
		Stephen Cullen
		Elvaron MediaSoft
		4 Andersonstown Drive
		BELFAST BT11 8FW
		County Antrim
		Northern Ireland

Homepage:	www.elvaronms.com
