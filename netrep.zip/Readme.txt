About Netrep
************

Netrep is an online monitoring tool. It can be used to monitor your
access to the internet and automatically calculates your bills.

Installation
************

To install Netrep run Setup.exe in the archive. This runs an
automated process of installing Netrep. 

Shareware
*********

Netrep is shareware. For more information see the help file or our
website.

Distribution
************

You may pass on unmodified versions of Netrep. You may not pass on
registered versions or keyfiles. The best way to pass a copy to
someone else is to point them to our website. See below.

Contact
*******

We welcome feedback and would like to help you with any problems 
you may have with Netrep. Please contact us:

Email:   support@alphatec.abel.co.uk
WWW:	 http://www.abel.co.uk/~alphatec/