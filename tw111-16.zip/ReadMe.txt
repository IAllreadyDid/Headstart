The Words - ReadMe
------------------
Read this before installing the program.

What is The Words?
------------------
The Words is an easy to use vocabulary learning program which you can use
when you learn a foreign language.
You write your own words with the program, save them as wordlists and then
you learn them. The Words is a freeware program.

Required files
--------------
Before you run this program, you must have the file VBRUN300.DLL
installed in Windows system directory.

You can download VBRUN300.DLL from:
ftp://ftp.simtel.net/pub/simtelnet/win3/dll/vbrun300.zip
or
ftp://ftp.sunet.se/pub/pc/mirror/simtelnet/win3/dll/vbrun300.zip

Extract the file and place VBRUN300.DLL in your Windows system directory.

Installation
------------
Run the Setup program, Tw11116.exe and it will install The Words to a directory which you choose.

Other notes
-----------
This is a 16-bit version and it works with Windows 3.1 and better.
There is also a 32-bit version of The Words. You can download both
versions from The Words Homepage.
Before you go to The Words Homepage from the program, make sure that
your web-browser is not running! Otherwise the function will not work.

E-mail & Homepage
-----------------
E-Mail: aki@swipnet.se (Use English, Swedish or Finnish)
Homepage: http://ssl.home.ml.org/thewords

/Good luck!
