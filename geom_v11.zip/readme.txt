Table of Contents
~~~~~~~~~~~~~~~~~~~

1. Purpose
2. Installation
3. Status
4. Distribution Status
5. Contact Information

==================
=   1. Purpose   =
==================
        The purpose of this program is to calculate the geometric figures
of different shapes.

=======================
=   2. Installation   =
=======================

Unzip the files to a directory of your choosing.  You may need PKUNZIP or
some other Zip file extractor.

=================
=   3. Status   =
=================
The status of this program is Freeware

==============================
=   4. Distribution Status   =
==============================
The distribution Status of this program is freely distributable

==============================
=   5. Contact Information   =
==============================

You may contact me at the following address ONLY.  As of right now, I do not
have a phone line that I can use.

email (not accurate - changes are possible):
        penacres@igateway.com

post office mail:
        Robert J. Pendell
        Attn: Product Support
        RR 1 Box 155-1D
        Elliottsburg, PA 17024

When you mail me your problem include your name, address(email if sent that
way), and your system information including memory available at the time.
