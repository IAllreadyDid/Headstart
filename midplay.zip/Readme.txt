		Midi Player ver. 1.13 - February 1997
		*************************************


CONTENTS:
*********
-FOREWARD
-RECOMMENDED HARDWARE SETUP
-INSTALATION
-REGISTERING THE SOFTWARE


       ****MAXIMISE NOTEPAD IN ORDER TO READ THIS FILE MORE EASILY****


MIDI PLAYER as provided here is shareware. This means that you can try it out
for free, and if you like it, pay the registration fee (see below) and
receive a registered version of the programme. You can use the shareware
version for as long as you want, but if you find it useful, please regisster
it. The registered version also has the following benefits:

- It allows the selection of up to thousands of MIDI files (from multiple
  directories) to be placed in the playlist.
- The annoying shareware notices will no longer appear.
- The PAUSE button works.

* Please send any bug reports/comments/suggestions to kmayer@mailorder.com
* To download the latest shareware version of MIDI PLAYER (and other useful
  software) go to:
  http://www.vianet.net.au/~mayer/Download.html



RECOMMENDED HARDWARE SETUP:
+++++++++++++++++++++++++++
* Windows 3.x or Windows '95 (Although this programme is not 32-bit, it runs
  better on Windows '95).
* 4 MB memory.
* 0.6MB free space on your hard drive.
* Sound card.



INSTALATION:
++++++++++++
* Make sure you have the file VBRUN300.DLL - you will most likely have this
  in your \WINDOWS\SYSTEM directory - if you don't then get it. You can
  download it from http://www.vianet.net.au/~mayer/Download.html
  THIS PROGRAMME WILL NOT RUN WITHOUT VBRUN300.DLL!!!!!!

* To install this programme run SETUP.EXE from File-Manager or Explorer.



REGISTERING THE SOFTWARE:
+++++++++++++++++++++++++
The cost of registering MIDI PLAYER is AU$15 (US$12). By registering you will
receive the full version and will be entitled to FREE updates of the
software whenever there are any bug fixes. If you have e-mail, and prefer to
have the registered version e-mailed to you rather than sent to you via a
floppy in snail mail, you will receive a discount.
If you want a collection of 50 music (MIDI) files, add an extra AU$3 (US$2)
to the total cost.
To receive a registered version, print out the following form, fill it out,
then send it, along with cash/money order/cheque to:
	Kevin Mayer
	75 Glanton Way
	Dianella  WA  6059
	Australia

-----------------------------------------------------------------------------
	
   NAME:______________________		E-MAIL:_______________________
ADDRESS:______________________		
	______________________
	______________________

I require a registered version of MIDI PLAYER via:
QTY
_____ - SNAIL MAIL: AU$15 (US$12)
_____ - E-MAIL: AU$12 (US$10)
_____ - COLLECTION OF MIDI FILES: AU$3 (US$2)

_____ - TOTAL COST (Specify whether payment is in Australian or US dollars.)

-----------------------------------------------------------------------------
