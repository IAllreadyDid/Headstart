This program is used to keep all of your CD information on disk,
for quick, easy access to any CD information.

This program is a shareware demo of the full program, feel free to 
distribute it to everyone possible.  It has all the features of the 
full program with the limitation of allowing only 21 CD's to be 
entered, instead of unlimited CD's

Features:

With CD File, you can:

1) Enter your CD's and view them in alphabetical order.
2) View the entire contents of any CD.
3) Edit or delete any CD.
3) Display all CD's by a specific artist by entering 1 to all of the
   characters of the artist.
4) Find a CD title or titles by entering 1 to all of the characters of
   the title.
5) Find any song or songs on any CD by entering 1 to all of the 
   characters of the song.
6) Find any song of a specified length on any CD.
7) Create and/or save a list of your favorite songs for use in creating 
   a recording.
8) Calculate which combination of your favorite songs list will fit 
   perfectly into a specified amount of time.
   (A side of a tape for instance)
9) Send the output to a printer at any point.
  

To use CD File:

 Place the 'CD_File.exe' and 'CDhelp' files in the same directory.  
Double click on the CD_File.exe file and the program will start.  All 
the instructions for using CD File can be accessed by pressing 'H' from
the main menu while the program is running.

If you place the program onto a floppy, you must be sure it is not 
write protected, because the program does a lot of writing to disk.  
You will get an error and the program will shut down if it is write 
protected.


To contact me in the event of questions or problems:

email: kevin.nielsen@sisna.com

address: 246 wilson ave
         SLC, UT 84115