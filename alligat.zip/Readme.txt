Alligat.exe

 1. Calculates volumes of two solutions of different concentrations 
    needed to make a final volume of a mixture of the 2 solutions. 
    This is a very tiny program that can come in handy when you want
    to cross check your math or if pressed by time.
 2. No installation required. To run, launch ALLIGAT.EXE
 3. This program is freeware.
 4. It is freely distributable.
 5. Contact Author at beraho@aol.com

