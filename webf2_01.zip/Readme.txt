=========================================================================
                        Webford 2.01 [Freeware]
                              Release Notes
                               README.TXT

                                 NOTICE
       ---------------------------------------------------------
       Copyright 1996, 1997 Jonathan Walsh. All rights reserved.

=========================================================================


WHAT IS WEBFORD?
================

Webford is a user-friendly software package for Windows that makes it 
easy for anybody to create and edit pages for the World Wide Web. It 
functions in a very similar manner to a simple word processing package,
except that it enables users to easily format documents with HyperText 
Markup Language (HTML) tags. 

Webford provides easy access to all of the most commonly used HTML tags. 
It includes useful features such as a wizard, pre-defined forms and
JavaScript functions, and enables you to create Web pages based on your 
own HTML templates. 

Through Webford, text can be formatted to change its appearance and
position, or to make it into a heading, a table, a list, or a link. 
Images and horizontal rules can be specified and inserted, the colours 
and background for a page can be changed with ease, and the system can
even open your favourite browser to let you see how your Web page looks. 
Webford can do all this and much more with a minimum of effort. 

Webford is compatible with Windows 3.1 and Windows 95. 


WHAT DOES WEBFORD COST?
=======================

Webford 2.01 is freeware, available to everyone free of charge.

All I ask in exchange is that if you create Web pages using Webford, 
please include a link to the Webford home page and send me an e-mail so 
that I will know how many people are using the system.

Please send messages, comments, bug reports etc. to:

     jwalsh@cableinet.co.uk

The Webford home page can be found at:

     http://wkweb4.cableinet.co.uk/jwalsh/webford/webford.htm


SYSTEM REQUIREMENTS
===================

To be able to use Webford 2.01 you will require the following:


-  IBM compatible PC with 386 processor or greater.
-  8 MB or more of RAM.
-  Microsoft Windows version 3.1 or higher.
-  A mouse.

If you would like to be able to test Web pages you will also require 
access to Web browser software such as Netscape Navigator or Internet 
Explorer.


WEBFORD 2.01 LICENSE AGREEMENT
==============================

Webford version 2.01 is provided free of charge. The software's author, 
Jonathan Walsh, grants to you a nonexclusive and royalty-free right to 
make, use and distribute an unlimited number of copies of the software, 
provided that copies are not distributed for profit, the software is 
not modified in any way, and each copy includes all of the associated 
files.

You may not reverse engineer, decompile, disassemble or modify this 
software in any way. 

This software may not be bundled with any commercial package without 
the explicit written permission of the author.

Webford version 2.01 is provided on an "AS IS" basis, without warranty 
of any kind, including without limitation the warranties of 
merchantability and fitness for a particular purpose. In no event shall 
the author be liable for any damages whatsoever resulting from loss of 
use, data, or profits arising out of or in connection with the use or 
performance of this software.


INSTALLING WEBFORD
==================

To install Webford 2.01, unzip the .ZIP file using software such as 
PKUNZIP or WinZip and run SETUP.EXE. 


RELEASE HISTORY
===============

FIRST RELEASE - 2.0 (AUGUST 1997)

RELEASE 2.01 (December 1997)

-  Fixed JavaScript error caused by people including ' characters in 
   link status bar text by replacing these characters with ` characters.

-  Avoided potential HTML errors by preventing " characters from being 
   entered into dialog boxes.

-  Added more pre-defined search engine links.

-  Added more pre-defined search engine forms.

-  Added option to have links opened in a new browser window.

-  Added options to have background sounds played continuously, and for 
   controls to be visible.

-  Added more special characters.

-  Added a message to inform user when text has been lost because a 
   reformatted document is too big.

-  Added help button to Web page wizard.

-  Removed "No Wrap" option from table data form.

-  Added more keyboard shortcuts.

-  Fixed problem of forms not closing properly when the Windows 95 form 
   closing button is used.

-  Modified JavaScript Date/Time function to display month and year in 
   full.

-  Changed the default HTML reference guide.

-  Modified wizard to permit blank lines to be inserted into text by 
   pressing RETURN, and to replace these with line break tags.

-  Improved pre-defined e-mail form.

-  Improved recently-used file list by including documents created 
   using wizard.



Webford is copyright � 1996, 1997 Jonathan Walsh. All rights reserved. 
