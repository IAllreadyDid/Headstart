TapeMate Shareware Version 1.00.18 Release Notes.
August 1998.

Program Name: 					TapeMate - The Ultimate Music Cassette Printing Utility.
Operating System:				Windows 3.1 or higher
Version:							1.00.18
Recommended BBS filename:	TAPEMATE.ZIP
Release Date: 					August 1998
Registration: 						�9.00 + �3.00 p&p (�5.00 for overseas orders)

Product Descriptions:
Short: Utility for creating inserts for music cassettes.

Long: Windows utility specifically designed for the creation of
index/inlay/J-cards for insertion into your music cassette cases.
In addition to inlay cards TapeMate can also generate Face labels 
for each side of your music cassettes and compact disc and 
cassette sized cards which can be used as dividers between 
CD and MC cases - useful if you like to keep you collections 
alphabetised.

TapeMate Features.
	�	Intuitive easy to use interface.
	�	Effortlessly create Cassette Inlay Cards (index/J-Cards) for you cassette cases.
	�	Have full control over typeface information for Cassette Inlay Cards.
	�	Print Face Labels for your tapes / cassettes
	�	Print Divider Cards for your compact disc's / cassettes
	�	Print in Colour.
	�	Save, load and preview Inlay cards.

Installing TapeMate
NOTE: If you use a virus protection program or have any other programs running on your computer,
close them down before using the TapeMate Set-up program. The Set-up procedure may not
function correctly with other programs loaded into memory. Once installed your can safely run other
programs along with TapeMate.

From Program Manager
	�	Start Microsoft Windows.
	�	Insert the TapeMate 'Installation Disk' into drive A: or B:
	�	From the File Menu in Program Manager, choose Run.
	�	Enter a:\setup or b:\setup in the dialogue box which appears on screen.
	�	Click the OK button or press ENTER.
	�	Follow the Set-up Instructions below.

From File Manager
	�	Start Microsoft Windows.
	�	Insert the TapeMate 'Installation Disk' into drive A: or B:
	�	Open File Manager by double-clicking on its icon.
	�	Select the toolbar icon representing the required drive A: or B:
	�	On the right hand side of the screen is the file list, locate and double-click on the filename 'SETUP.EXE'.
	�	Follow the Set-up Instructions below.

Set-up Instructions
Following on from whichever procedure used above, you will then be asked to:-

�	Supply the destination directory that you want TapeMate installed to. The default
directory is C:\TAPEMATE, but this can be changed to another directory if the default is not
suitable.

�	Click Continue to move on.
Set-up will then start copying the necessary files to the specified destination directory.
A Program Manager Group containing the TapeMate Program Icons will then be created for you. To
start TapeMate, simply double-click on the icon and the application will load.

Starting-up TapeMate.
If you are still in DOS, start Microsoft Windows by typing Win at the DOS C:> prompt, then press
[ENTER]. This will load the Windows Operating Environment.

Once Windows is loaded, locate and double-click on the TapeMate icon. This will activate the
program and load it into memory. Once loaded the About dialogue will be displayed. Just click the
Continue button to proceed.

Documentation.
Complete documentation is provided on-line in Windows Help format. This can be called at any time
from within the TapeMate program or by double-clicking on the TapeMate Help file in File Manager.
An icon is also created and placed in the TapeMate Program Manager window when the program
was installed.

Version History.
See accompanying help file for complete history of changes to TapeMate.

If you need to contact the author for whatever reason you can do so by sending email to stevo@elvaronms.com. Alternatively, you can write to:-
		Stephen Cullen
		Elvaron MediaSoft
		4 Andersonstown Drive
		BELFAST BT11 8FW
		County Antrim
		Northern Ireland

Homepage:	www.elvaronms.com
