ZDA 1.1
---
Zda, the software, is a fortune telling programme based 
on a prehistoric power also known as Zda. The programme 
includes a fortune telling section and a decision making 
section. For more information about Zda, please visit http://www.jpb.com/zda/.

Zda can be used on any PC computer running Windows 3.1 or 
Windows 95. A 256 colour monitor is recommended for best 
results.

In order to install Zda, simply unzip it and double click on the 
setup.exe file. Alternatively, unzip Zda and then click on the 
"My Computer" Icon, select "Control Panel" and "Ad/Remove Programs". 
Click the "Install Button" and select "setup" from the directory 
in which you unzipped Zda

Zda is a shareware. You may try it out for a limited number of times 
after which it stops functioning. If you wish to use Zda indefinitely, 
you must register (see the Register.txt file for information on 
registering). Registering entitles you to free technical help and 
free upgrades until version 2.0. You may freely distribute the 
uninstalled version of Zda (either zipped or unzipped) without 
restriction. 

If you have any questions or comments regarding Zda, please contact:

ZDA Software Division
JPB Creative Co, Ltd
12/23 Soi Prommitr
Sukhumvit 39 Road
Bangkok 10110 Thailand

Tel: +66(2)258 8451, 259 7058
Fax: +66(2)261 6679

E-mail: zda@jpb.com or info@jpb.com
http://www.jpb.com/zda/

Thanks for trying Zda
