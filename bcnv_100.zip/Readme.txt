DISCLAIMER: THIS PROGRAM COMES WITH NO WARRANTY OF ANY KIND. I AM NOT
RESPONSIBLE FOR ANY DAMAGES WHICH MIGHT OCCUR FROM THE USE OF THIS
PROGRAM. 

THIS PROGRAM IS DISTRIBUTED AS FREEWARE. AT NO TIME SHOULD THIS PROGRAM,
OR PARTS OF IT BE CHARGED MONEY WITHOUT MY  PERMISSION. CHARGING
MONEY FOR THIS PROGRAM WITHOUT MY PERMISSION IS A VIOLATION OF
APPLICABLE LAWS.

BY USING THIS PROGRAM YOU AGREE TO THE ABOVE TERMS.

Instant Base Converter is program for conversion between different 
numerical systems. Currently are the four common systems (Dec, Bin, Oct
and Hex) and one with a custom base supported.

Installation: Unzip bcnv_100.zip to a directory of your choice and
run basecnv.exe.

To make this program start in minimized state, just exit the program
when it's minimized. This is great if you want it in you autostart.

Don't type any value exceeding 2.147.483.647 in this version of
Instant Base Converter. If you do an Overflow Run-time error will 
occur and the application will terminate.

If you have any comments, questions or suggestions about this product,
feel free to mail me at mammoth@unforgettable.com.

Copyright (c) Robin Palm 1998