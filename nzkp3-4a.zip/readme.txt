KWIKPAY NEW ZEALAND PAYROLL

KwikPay is a complete payroll system for New Zealand small businesses. It includes all current tax rates, full IRD reporting including approved computer printed IR348 forms, and EDT file format. It also has provision for the accrual of leave entitlements.

KwikPay is based on a simple interactive payslip screen that displays immediately the affect of any change to an employee�s pay data. There is provision for supplementary, out of cycle and manual, adjustment pays. 

KwikPay�s transaction scheduler enables payments or deductions to be scheduled at frequencies different from employees� pay frequency and can even apply a payment or deduction to every employees� pay with a single transaction. It also has a flexible data import process which can import pay data from time clocks, spreadsheets or any other software capable of creating an ASCII text file.

The basic KwikPay system already includes direct credit interfaces to the electronic funds transfer systems of all of the banks, building societies and credit unions. It also has full provision for cash and cheque pays.

All of the ATO statutory reporting requirements are met, from tax period schedules to end of year returns. KwikPay has been approved by the ATO to produce Group Certificate data on floppy disk and print Group Certificates on plain paper. It is also able to utilise the ATO pre-printed Group Certificate forms.

Accounting of pay data is no problem as KwikPay can allocate individual payments and deductions to different departments, cost centres or jobs. A set of standard payments and deductions are provided with the system, which is easy to customise and extend with new payment and deduction types.

The system includes leave accrual and payments, with the facility to accrue RDO leave as a percentage of hours or number of shifts worked. There is a full selection of eligible termination payments with the correct calculation of tax on any type of payment. PAYE tax can be averaged over a number of pay periods on an individual payment or whole payslip basis.

KwikPay uses an Access database to store employee and pay data, so it is easy to use employee data for mailing lists, or include pay data in spreadsheets. All of KwikPay reports were developed using Crystal Reports, the leading Windows report writer. KwikPay Software is happy to quote for the customisation of reports, or advise users how to customise the reports themselves using Crystal Reports.

INSTALLATION INSTRUCTIONS

Run the nzw16.exe unzipped with this readme.txt file. It will install the KwikPay application software on your hard drive. In order to run the software, you will also need to install some third party components. These system support files are installed using kp16sup.zip which can be downloaded from /pub/simtelnet/win3/business/
Download the 16 bit system files, and install them by running the w16system.exe file.

PROGRAM STATUS

KwikPay is a shareware program. You are free to copy and distribute both the KwikPay application and it's system components file. You can use the program to check your own pay calculations free of charge. Up to two employees can be processed for an unrestricted length of time. If you wish to load more than two employees, you will need to purchase a registration key.

REGISTER KWIKPAY

You can purchase a registration key for KwikPay by sending us the company name you wish to register, together with a cheque for NZ$50 payable to KwikPay Software at:
	P O Box 1025
	Burpengary
	QLD 4506
We will send you a registration key (by e-mail if you include your e-mail address), and details of any program updates. We will also add you to our mailing list so you receive information on future updates.

ANY PROBLEMS OR SUGGESTIONS?

Contact the author, Alastair Robertson, by e-mail at:
	support@kwikpay.com.au
by fax on:
	07 3886 7661
or by post at:
	P O Box 1025
	Burpengary
	QLD 4506
I will be pleased to hear of any suggestions for improvements. Thank you for trying KwikPay.