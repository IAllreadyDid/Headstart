 

  ========================== StartPage 1.0 Readme ==========================
 
     
     This version of StartPage is compatible with Netscape and Internet Explorer. Although Internet Explorer users will not be able to use the search features provided by Poke. 
  
  
   # Getting Started:
     StartPage is very easy to use and doesn't require any knowledge of HTML programing. When you run it for the first time, you just will be asked to type  your name and the URL your browser is actually starting with. StartPage will make a button on your new home page linking to this URL, this means YOU WILL NOT LOOSE YOUR ACTUAL HOME PAGE. You will be able to access it directly from your new home page.
    
    Following you'll choose the graphic settings (main picture, background and text color). Once you provide this information, StartPage will build your page using some default settings.
  
  
   # Testing:
     
     When you finish to run StartPage the URL of your new home page will be automatically copied onto the clipboard. You can take a look at your page by pasting the URL on the "location:" box of your browser. Go online and test  your page.

   # Customizing:
  
     Now you have seem how your page looking like it will be easy to make changes replacing the "Preferred Sites" and "E-mail Address" by your own choice. From the second time you run the program, it will always open with an editing form. You can the changes gradually running The StartPage Program as many time as you want. Whenever you do it your StartPage will be updated.   
  
   # Setting Your New Home Page on Your Browser:
  
     After run StartPage the URL of your new home page will be automatically copied onto the clipboard. You just have to look for the option menu of your browser and find the right place to paste it.
 
     On Netscape 2.0  open The options menu choose "General Preferences" then Appearance look for "Start With", check "Home Page Location" and paste the URL on the box right below.
  Once you have set you your browser, it will always start with your customized page and it will be load every time you hit the home button.
  

  ***** StartPage is a Freeware feel free to use and distribute it. *******
 
 Disclaimer: StartPage is provided without any type of guaranties.
Netscape is a trademark of Netscape Communications Corporation, Yahoo! is a trademark of Yahoo! Inc., and Poke is provided by Webprowler.com.

    