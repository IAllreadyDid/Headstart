Purpose: English language grammar reference.

Installation: No special requirements. GR3.EXE can be extracted to a directory or folder of your choice.

Status: Shareware.

Distribution Status: Freely distributable.

Author Contact:	Richard C. Waite, Jr.
				e-mail: rcwaite2@pacbell.net
				Phone: (805) 658-1229
